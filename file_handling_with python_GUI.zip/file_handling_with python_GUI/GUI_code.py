import os,shutil

folders={
    "IMAGES": [".jpeg", ".jpg", ".tiff", ".gif", ".bmp", ".png", ".bpg", "svg",
               ".heif", ".psd",".iso",".img",".vcd",".dmg"],
    "VIDEOS": [".avi", ".flv", ".wmv", ".mov", ".mp4", ".webm", ".vob", ".mng",
               ".qt", ".mpg", ".mpeg", ".3gp",".mkv"],
    "DOCUMENTS": [".oxps", ".epub", ".pages", ".docx", ".doc", ".fdf", ".ods",
                  ".odt", ".pwi", ".xsn", ".xps", ".dotx", ".docm", ".dox",
                  ".rvg", ".rtf", ".rtfd", ".wpd", ".xls", ".xlsx", ".ppt",
                  "pptx",".md",".pages",".numbers"],
    "AUDIO": [".aac", ".aa", ".aac", ".dvf", ".m4a", ".m4b", ".m4p", ".mp3",
              ".msv", "ogg", "oga", ".raw", ".vox", ".wav", ".wma"],
    "PDF":[".pdf"],
    "TEXT":[".txt"],
    

}

def rename_folder():# for rename folder incase of avoidiong dublicate foders and earrors  
    for folder in os.listdir(diractory):
        if os.path.isdir(os.path.join(diractory,folder))==True:
            os.rename(os.path.join(diractory,folder),os.path.join(diractory,folder.lower()))
            break

def create_move(ext,file_name): 
    find=False
    for folder_name in folders:
        if "."+ext in folders[folder_name]: 
            # check if our dictonary folder is already available or not 
            if folder_name not in os.listdir(diractory): 
                #make folder in selected path
                os.mkdir(os.path.join(diractory,folder_name ))  
            # move the iteams into folders
            shutil.move(os.path.join(diractory,file_name),os.path.join(diractory,folder_name )) 
            find=True
            break
    if find!=True:
        if other_name not in  os.listdir(diractory):
            os.mkdir(os.path.join(diractory,other_name))
        shutil.move(os.path.join(diractory,file_name),os.path.join(diractory,other_name))
        



# take path from user
diractory=input("enter the locaction: ")
other_name=input("enter name for UNKNOWN files: ")
rename_folder()

all_files=os.listdir(diractory)
length=len(all_files)
count=1
# check in my list all objects are file 
for i in all_files:
    if os.path.isfile(os.path.join(diractory,i))==True:
        create_move(i.split(".")[-1],i)  
    print(f"Total files: {length}| Done: {count} | Left: {length-count} ")
    count+=1











